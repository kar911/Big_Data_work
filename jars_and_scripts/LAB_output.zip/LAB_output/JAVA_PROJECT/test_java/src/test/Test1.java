package test;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test1.abc();
		
	}

	public static void abc(){
		Test1.lml();
		System.out.println("in abc");
	}
	public static void lml(){
		
		System.out.println("in lml");
		//System.out.println(5/0);
		String a = null;
		System.out.println(a.toLowerCase());
	}
	
}
