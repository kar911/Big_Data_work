#!/bin/bash
pig pig_script
